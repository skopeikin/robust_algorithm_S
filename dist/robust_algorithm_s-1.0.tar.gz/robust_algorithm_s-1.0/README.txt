The purpose of this software is to use it for statistical data processing, especially for robust analysis and giving robust estimates for data,
which contains abnormal results.